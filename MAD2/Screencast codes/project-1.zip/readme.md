# Sending Email from Python
Welcome to the Modern Application Development - 2 Screencasts. In this screencast we will see how to send emails.

# Send Email
    - SMTP Server, Why? And built in library    
    - Fake SMTP Server
    - Library to use send email
    - Library to use send email with attachment
    - Use templates for formatting

# How to push to back ground
- Main Task
    - Get users
    - Loop
        - Get data and email_template for this user
        - `celery.execute.send_task("task.send_email", args=[], kwargs={})`
        - call email sending task
            - Format template
            - Send email

# Links
- https://docs.python.org/3/library/smtplib.html
- https://docs.python.org/3/library/email.examples.html#email-examples
- https://thejeshgn.com/2022/02/11/linked-list-fake-or-mock-smtp-servers-for-email-testing/