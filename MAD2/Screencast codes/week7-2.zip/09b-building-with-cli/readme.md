npm install -g @vue/cli
npm i -g @vue/cli-service-global
npm run serve