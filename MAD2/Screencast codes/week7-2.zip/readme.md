9. Vue CLI ✍️
    - 09a-vue-cli-sfc.mp4
        - What is node
        - how to install 
        - What is Vue cli
        - Why Vue cli    
        - Runing a vue file, SFC
    - 09b-building-with-cli.mp4
        - How to use for create and build
        - Build options
        