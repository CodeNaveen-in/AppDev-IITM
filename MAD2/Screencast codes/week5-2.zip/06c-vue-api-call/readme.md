# API calls from Vue
Welcome to the Modern Application Development - 2 Screencasts. In this screencast we will explore fetch API along with Vue.

For this you will need 

- Browser Firefox or Chrome
- I am using firefox
- We will also be using online tool - https://httpbin.org for checking our requests.

## API calls
- You will have to do API calls to get some initial data to setup the components. 
- You could also use them to fetch the data based on user request
- You could also save the data backend based on some events or user request

For all of these you could use fetch API.



## Watchers
https://vuejs.org/v2/guide/computed.html#Watchers
    