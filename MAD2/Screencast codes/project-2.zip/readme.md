# Sending Email from Python
Welcome to the Modern Application Development - 2 Screencasts. In this screencast we will see how to create PDF reports.

We will use jinja to create the report using a template and data. Then we will use weasyprint library to convert that into PDF.

# Install
https://doc.courtbouillon.org/weasyprint/stable/first_steps.html#ubuntu-20-04


# Style
The @page CSS at-rule is used to modify some CSS properties when printing a document.


https://developer.mozilla.org/en-US/docs/Web/CSS/@page

```css
        @page {
            size: Letter; /* Change from the default size of A4 */
            margin: 3cm; /* Set margin on each page */
            
        }
```        