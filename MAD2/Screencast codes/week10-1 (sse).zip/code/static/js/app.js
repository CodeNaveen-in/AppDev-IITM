new Vue({
        el: "#app",
         delimiters: ['${', '}'],
        data() {
          return {
            msg: "Hello World from Vue!"
          }
        }
      });