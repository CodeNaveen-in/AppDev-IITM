# How to secure the API end points

Welcome to the Modern Application Development - 2 Screencasts. In this screencast we will see how to seaprate front end and backend application.

- Terminal
- Browser
- Editor
- Python


# Seaprate Front End App

In this approach we will use seaprate front end app. And we will use flask only for API. The front end app could be 


https://cli.vuejs.org/config/#publicpath
https://testdriven.io/blog/developing-a-single-page-app-with-flask-and-vuejs/
https://testdriven.io/blog/combine-flask-vue/
https://trio.dev/blog/why-use-vue-js